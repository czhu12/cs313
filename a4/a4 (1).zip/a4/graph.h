#define N (8 * 1024)
